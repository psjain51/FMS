package com.flp.fms.test;

import static org.junit.Assert.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;

import com.flp.fms.dao.FilmDaoImplForDB;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;



public class FilmDaoTest {

	FilmDaoImplForDB filmDao=new FilmDaoImplForDB();
	
	@Test
	public void checkRetrieveFilmId() throws Exception{
		assertEquals(4,filmDao.retrieveFilmId());
	}

			
	
    
    
	//TEST CASES FOR ADD FILM
	//1.Film object should not be null
	
	//2.When is film successfully added


	@Test
	public void WhenFilmObjectIsNull()
	{

		assertEquals(filmDao.addFilm(null),"Film object is null");
	}

	/*@Test
	public void WhenFilmObjectIsSuccessfullyAdded()
	{
		Language lang1= new Language(1, "English");
		Language lang2=new Language(2, "Hindi");
		Language lang3=new Language(3, "Marathi");
		List<Language> languages=new ArrayList<>();
		languages.add(lang1);
		languages.add(lang3);
		
		Category category=new Category(1, "Drama");
		Set<Actor> actors=new HashSet<>();
		Actor act1=new Actor(1,"Aamir", "Khan");
		Actor act2=new Actor(2, "Gracy", "Singh");
		actors.add(act1);
		actors.add(act2);
		
		Date releaseDate=new Date("12-may-2001");
		Date rentalDuration=new Date("31-nov-2009");
		
		Film film=new Film("Lagaan", "Epic historical", releaseDate, languages, lang2, rentalDuration, 123, 500000, 4, "Cricket Match", actors, category);
		assertEquals(filmDao.addFilm(film),"Film added successfully");
	}*/
	
    
	//TEST CASES FOR SEARCH BY RATING
		//1. FILM object null
		//2.Film rating not found
		//3.Film Successfully found by rating
		
		

		@Test
		public void WhenFilmObjectDuringSearchingByRatingIsNull()
		{
			
			assertEquals(filmDao.searchFilmByRating(1).size(),0);
			
		}
		
		@Test
		public void WhenFilmObjectIsNotNullButFilmRatingrNotFound()
		{
			assertEquals(filmDao.searchFilmByRating(2).size(),0);
		}
		
		
		
		@Test
		public void WhenFilmRatingIsSuccessfullySearched()
		{
			
			assertEquals(filmDao.searchFilmByRating(4).size(),3);
			
		
		
		}
		
	
		//TEST CASES FOR SEARCH BY LANGUAGE
		//1. Film object NULL 
		//2. Film language Not Found
		//3. Film Searched Successfully By Language
		
		
		
		@Test
		public void WhenFilmObjectDuringSearchingByLanguage()
		{
			Language language=new Language();
			assertEquals(filmDao.searchFilmByLanguage(language).size(),0);
			
		}
		
		@Test
		public void WhenFilmObjectIsNotNullButFilmLanguageNotFound()
		{
			Language language=new Language(20, "Greek");
			assertEquals(filmDao.searchFilmByLanguage(language).size(),0);
		}
		
		@Test
		public void WhenFilmLANGUAGEIsSuccessfullySearched()
		{
			Language language=new Language(2, "Hindi");
			assertEquals(filmDao.searchFilmByLanguage(language).size(),3);
			
		}
	      
		//TEST CASES FOR SEARCH FILM BY ACTOR
			//1.Film object not found during search film by actor
			//2.Film actor not found
			//3.Film Successfully searched by actor
	
		@Test
		public void WhenFilmObjectDuringSearchingByActor()
		{
			Actor actor=new Actor();
			assertEquals(filmDao.searchFilmByActor(actor).size(),0);
			
		}
		
		@Test
		public void WhenFilmObjectIsNotNullButFilmActorNotFound()
		{
			Actor actor=new Actor(34, "Tom", "Cruise");
			assertEquals(filmDao.searchFilmByActor(actor).size(),0);
		}
		
		@Test
		public void WhenFilmActorIsSuccessfullySearched()
		{
			Actor actor=new Actor(1, "Hrithik", "Roshan");
			assertEquals(filmDao.searchFilmByActor(actor).size(),3);
		
		}

		//TEST CASES FOR SEARCH FILM BY ID
		//1.Film object not found during search film by ID
		//2.Film Successfully searched by ID
		
		@Test
		public void WhenFilmIdisFound(){
			Language lang1= new Language(1, "English");
			Language lang2=new Language(2, "Hindi");
			Language lang3=new Language(3, "Marathi");
			List<Language> languages=new ArrayList<>();
			languages.add(lang1);
			languages.add(lang3);
			
			Category category=new Category(2, "Comedy");
			Set<Actor> actors=new HashSet<>();
			Actor act1=new Actor(1, "Hrithik", "Roshan");
			Actor act2=new Actor(2, "Ranbir", "Kapoor");
			actors.add(act1);
			actors.add(act2);
		
			
			Date releaseDate=new Date("12-may-2001");
			Date rentalDuration=new Date("31-nov-2009");
			
			Film film=new Film("Lagaan", "Epic historical", releaseDate, languages, lang2, rentalDuration, 123, 500000, 4, "Cricket Match", actors, category);
			Film film1=filmDao.searchFilmById(3);
			assertFalse(film1.equals(film));
		}
		
		@Test
		public void WhenFilmIdisNotFound(){
			Language lang1= new Language(1, "English");
			Language lang2=new Language(2, "Hindi");
			Language lang3=new Language(3, "Marathi");
			List<Language> languages=new ArrayList<>();
			languages.add(lang1);
			languages.add(lang3);
			
			Category category=new Category(2, "Comedy");
			Set<Actor> actors=new HashSet<>();
			Actor act1=new Actor(1, "Hrithik", "Roshan");
			Actor act2=new Actor(2, "Ranbir", "Kapoor");
			actors.add(act1);
			actors.add(act2);
		
			
			Date releaseDate=new Date("12-may-2001");
			Date rentalDuration=new Date("31-nov-2009");
			
			Film film=new Film("Lagaan", "Epic historical", releaseDate, languages, lang2, rentalDuration, 123, 500000, 4, "Cricket Match", actors, category);
			Film film1=filmDao.searchFilmById(56);
			assertFalse(film1.equals(film));
		}
    
  	}