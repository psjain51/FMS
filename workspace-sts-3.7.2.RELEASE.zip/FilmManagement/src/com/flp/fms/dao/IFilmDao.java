package com.flp.fms.dao;



import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface IFilmDao {
	
	public List<Language> getLanguages();
	public List<Category> getCategories();
	
	public String addFilm(Film film);
	
	public Map<Integer, Film> getAllFilms();
	
	public String updateFilm(Film film);
	
	
	public void removeFilmByActor(Actor actor);
	public void removeFilmByRating(int rating);
	public void removeFilmByTitle(String title);
	public void removeFilmById(int filmId);
	
	
	
	public List<Film> searchFilmByActor(Actor actor);
	public List<Film> searchFilmByLanguage(Language language);
	public List<Film> searchFilmByRating(int rating);
	public Film searchFilmByTitle(String title);
	public Film searchFilmById(int filmId);
	


}
