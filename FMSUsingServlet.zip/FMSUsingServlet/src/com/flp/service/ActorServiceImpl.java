package com.flp.service;

import java.util.List;


import com.flp.fms.Dao.ActorDaoImplFordb;
import com.flp.fms.domain.Actor;
import com.sun.org.apache.bcel.internal.generic.ACONST_NULL;

public class ActorServiceImpl implements IActorService {
	
	ActorDaoImplFordb actorDao=new ActorDaoImplFordb();
	@Override
	public List<Actor> getActorList() {
		
		return actorDao.getActorList();
	}
	@Override
	public int addActor(Actor actor) {
		// TODO Auto-generated method stub
		return actorDao.addActor(actor);
	}
	public int removeActor(int id) {
		
		return actorDao.removeActor(id);
	}
	@Override
	public Actor getActorByID(int id) {
		// TODO Auto-generated method stub
		return actorDao.getActorByID(id);
	}
	public int updateFilm(Actor actor, int actorId) {
		
		return actorDao.updateFilm(actor, actorId);
	}
	
}
