package com.flp.fms.Dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Actor;

public class ActorDaoImplFordb implements IActorDao{

	FilmDaoImpForOrgLang filmDao=new FilmDaoImpForOrgLang();
	@Override
	public List<Actor> getActorList() {
		List<Actor> actor=new ArrayList<>();
		
		
		Connection con=filmDao.getConnection();
		
		String sql="select * from ACTOR";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Actor actor1=new Actor();
				actor1.setActor_Id(rs.getInt(1));
				actor1.setActor_Fname(rs.getString(2));
				actor1.setActor_Lname(rs.getString(3));
				actor.add(actor1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return actor;
	}

	@Override
	public int addActor(Actor actor) {
		Connection con=filmDao.getConnection();
		String sql="insert into ACTOR(firstName,lastName)"
				+ "	 values(?,?)";
		
		int count=0;
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, actor.getActor_Fname());
			pst.setString(2, actor.getActor_Lname());
			
			count=pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	public int removeActor(int id) {
		int count=0;
		
		Connection con=filmDao.getConnection();
		
		String  sql="delete from ACTOR where actor_id=?";
		String sql1="delete from film_actors where actor_id=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, id);
			count=pst.executeUpdate();
			
			
			PreparedStatement pst1=con.prepareStatement(sql1);
			pst1.setInt(1, id);
			count=pst1.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return count;
	}

	
	//SEARCH ACTOR BY ID
	@Override
	public Actor getActorByID(int id) {
		
        Actor actor=new Actor();
		Connection con=filmDao.getConnection();
		String sql="select * from ACTOR where actor_id=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, id);
			ResultSet rs=pst.executeQuery();
			
			
			while(rs.next())
			{
				actor.setActor_Fname(rs.getString(2));
				actor.setActor_Lname(rs.getString(3));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return actor;
	}

	@Override
	public int updateFilm(Actor actor, int actorId) {
		int count=0;
		
	    Connection con=filmDao.getConnection();
	    String sql="update ACTOR set firstName=?,lastName=? where actor_id=?";
	    
	    
	    try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, actor.getActor_Fname());
			pst.setString(2, actor.getActor_Lname());
			pst.setInt(3, actorId);
			
			
			count=pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    
	
	
	
	
	        return count;
	}

	

}
