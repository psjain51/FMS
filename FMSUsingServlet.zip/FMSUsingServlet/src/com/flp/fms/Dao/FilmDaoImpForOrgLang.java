package com.flp.fms.Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.flp.fms.domain.Film;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;

public class FilmDaoImpForOrgLang implements IFilmDao{

	private Map<Integer, Film> film_Repository=new HashMap<>();
	@Override
	public List<Language> getOriginalLanguage() {
   
		List<Language>languages=new ArrayList<>();
		
		
		
		Connection con=getConnection();
		String sql="select * from LANGUAGE";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Language lang=new Language();
				lang.setLanguage_Id(rs.getInt(1));
				lang.setLanguage_Name(rs.getString(2));
				
				
				languages.add(lang);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return languages;
	}

	@Override
	public List<Category> getCategory() {
		List<Category> category=new ArrayList<>();
		
		Connection con=getConnection();
		String sql="select * from CATEGORY";
		
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Category category1=new Category();
				category1.setCategory_Id(rs.getInt(1));
				category1.setCategory_Name(rs.getString(2));
				
				
				category.add(category1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return category;
	}
	
	//CURD Operation
		@Override
		public int addFilm(Film film) {
			
		
			Connection con=getConnection();
			String sql="insert into FILM(title,description,releaseYear,originalLanguage,rentalDuration,LENGTH,replacementCost,ratings,specialFeatures,category)"
					+ "	 values(?,?,?,?,?,?,?,?,?,?)";
			
			int count=0;
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setString(1, film.getTitle());
				pst.setString(2, film.getDescription());
				pst.setDate(3, new Date(film.getRealeaseYear().getTime()));
				int language=film.getOriginalLanguage().getLanguage_Id();
				pst.setInt(4, language);
				pst.setDate(5, new Date(film.getRentalDuration().getTime()));
				pst.setInt(6, film.getLength());
				pst.setDouble(7,film.getReplacementCost());
				
				pst.setInt(8,film.getRatings());
				pst.setString(9,film.getSpecialFeatures());
				int category=film.getCategory().getCategory_Id();
				pst.setInt(10,category);
				count=pst.executeUpdate();
				
				
				//Fetching last film id 
				String sql1="select filmid from FILM order by filmid desc limit 1 ";
				PreparedStatement pst1=con.prepareStatement(sql1);
				ResultSet rs=pst1.executeQuery();
				int film_id=0;
				while(rs.next())
				{
					film_id=rs.getInt(1);
					
				}
				
				
				//insert into film_languages
				String sql2="insert into film_language values(?,?)";
				PreparedStatement pst2=con.prepareStatement(sql2);
			     List<Language> lang=film.getLanguages();
			     System.out.println(lang);
				for(Language lang1:lang){
				pst2.setInt(1, film_id);
				pst2.setInt(2,lang1.getLanguage_Id());
			    count=pst2.executeUpdate();
				}
				
				String sql3="insert into film_actors values(?,?)";
				PreparedStatement pst3=con.prepareStatement(sql3);
			    List<Actor> actor=film.getActors();
				for(Actor act1:actor){
				pst3.setInt(1, film_id);
				pst3.setInt(2,act1.getActor_Id());
				 count=pst3.executeUpdate();
				}
				
				
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(film);
			return count;
		}


		@Override
		public List<Film> getAllFilms() {
			
			Connection con=getConnection();
			List<Film> films=new ArrayList<>();
			String sql="select * from FILM";
			
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				ResultSet rs=pst.executeQuery();
				while(rs.next()){
					Film film=new Film();
					film.setFilm_Id(rs.getInt(1));
					film.setTitle(rs.getString(2));
					film.setDescription(rs.getString(3));
					film.setRealeaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));
					//Original Language
					int lang_id=rs.getInt(5);
					Language orgLang=getOrgLang(lang_id);
					film.setOriginalLanguage(orgLang);
					
					//Rental Duration
					film.setRentalDuration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
					
					//length
					film.setLength(rs.getInt(7));
					
					//replacementCost
					film.setReplacementCost(rs.getDouble(8));
					
					//rating
					film.setRatings(rs.getInt(9));
					
					//Special Features
					film.setSpecialFeatures(rs.getString(10));
					
					int category_id=rs.getInt(11);
					Category category=getCategoryforListing(category_id);
					film.setCategory(category);
					
					//other Lang
					List<Integer> lang_ids=getLanguagesIDs(film.getFilm_Id());
					List<Language> lang_name=new ArrayList<>();
					for(Integer langid:lang_ids){
						lang_name.add(getOrgLang(langid));
					}
					film.setLanguages(lang_name);
					
					//Actors
					
					
					List<Actor> act=new ArrayList<>();
					List<Integer> actor_id=getActorIDS(film.getFilm_Id());
					for(Integer actor:actor_id){
						act.add(getActors(actor));
					}
					film.setActors(act);
					films.add(film);
					
					
				}
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			
	
			return films;
			
		
		}
		
		
		private Actor getActors(int actor) {
			Actor actor1=new Actor();
			Connection con=getConnection();
			String str="select * from ACTOR where actor_id=?";
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, actor);
				ResultSet rs=pst.executeQuery();
				while(rs.next()){
					actor1.setActor_Fname(rs.getString(2));
					actor1.setActor_Lname(rs.getString(3));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return actor1;
		}

		private List<Integer> getActorIDS(int film_Id) {


			Connection con=getConnection();
			List<Integer> actorids=new ArrayList<>();
			String str="select * from film_actors where film_id=?";
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, film_Id);
				ResultSet rs=pst.executeQuery();
				
				
				while(rs.next()){
					actorids.add(rs.getInt(2));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return actorids;
		}

		private List<Integer> getLanguagesIDs(int film_Id) {
			
			Connection con=getConnection();
			String str="select * from film_language where film_id=?";
			List<Integer> id=new ArrayList<>();
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, film_Id);
				ResultSet rs=pst.executeQuery();
				
				
				while(rs.next()){
					id.add(rs.getInt(2));
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return id;
		}

		private Category getCategoryforListing(int category_id) {
			Connection con=getConnection();
			Category category=new Category();
			String str="select * from CATEGORY where categoryID=?";
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, category_id);
				ResultSet rs=pst.executeQuery();
				
				while(rs.next()){
					category.setCategory_Name(rs.getString(2));
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return category;
		}

		public Language getOrgLang(int langid){
		
			
			Language lang=new Language();
			Connection con=getConnection();
			String str="select * from LANGUAGE where languageID=?";
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, langid);
				ResultSet rs=pst.executeQuery();
				
				while(rs.next()){
					lang.setLanguage_Name(rs.getString(2));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return lang;
			
		}

		@Override
		public Map<Integer, Film> searchFilm() {
			return film_Repository;
			
		}

		@Override
		public int removeFilm(int id) {
			
			Connection con=getConnection();
			int count=0;
			
			String str="delete from FILM where filmid=?";
			String str1="delete from film_language where film_id=?";
			String str2="delete from film_actors where film_id=?";
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, id);
			    count=pst.executeUpdate();
			    
			    
			    
			    PreparedStatement pst1=con.prepareStatement(str1);
			    pst1.setInt(1, id);
			    count=pst1.executeUpdate();
			    
			    
			    PreparedStatement pst2=con.prepareStatement(str2);
			    pst2.setInt(1, id);
			    count=pst2.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			return count;
			
			
		}


		public Connection getConnection(){
			
			Connection connection=null;
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
				connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/filmmanagementsystem","root","Pass1234");
				
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			return connection;
		}

		public Film getSearchFilmByID(int id) {
			Connection con=getConnection();
			Film film=new Film();
			String sql="select * from FILM where filmid=?";
			
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setInt(1, id);
				ResultSet rs=pst.executeQuery();
				while(rs.next()){
				/*	Film film=new Film();*/
					film.setFilm_Id(rs.getInt(1));
					film.setTitle(rs.getString(2));
					film.setDescription(rs.getString(3));
					film.setRealeaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));
					//Original Language
					int lang_id=rs.getInt(5);
					Language orgLang=getOrgLang(lang_id);
					film.setOriginalLanguage(orgLang);
					
					//Rental Duration
					film.setRentalDuration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
					
					//length
					film.setLength(rs.getInt(7));
					
					//replacementCost
					film.setReplacementCost(rs.getDouble(8));
					
					//rating
					film.setRatings(rs.getInt(9));
					
					//Special Features
					film.setSpecialFeatures(rs.getString(10));
					
					int category_id=rs.getInt(11);
					Category category=getCategoryforListing(category_id);
					film.setCategory(category);
					
					//other Lang
					List<Integer> lang_ids=getLanguagesIDs(film.getFilm_Id());
					List<Language> lang_name=new ArrayList<>();
					for(Integer langid:lang_ids){
						lang_name.add(getOrgLang(langid));
					}
					film.setLanguages(lang_name);
					
					//Actors
					
					
					List<Actor> act=new ArrayList<>();
					List<Integer> actor_id=getActorIDS(film.getFilm_Id());
					for(Integer actor:actor_id){
						act.add(getActors(actor));
					}
					film.setActors(act);
					/*films.add(film);*/
					
					
				}
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			return film;
		}

		@Override
		public int updateFilm(int id,Film film) {
			//System.out.println(id+"dao");
			int  count=0;
			Connection con=getConnection();
			String sql="update FILM set title=?,description=?,releaseYear=?,originalLanguage=?,rentalDuration=?,LENGTH=?,replacementCost=?,ratings=?,specialFeatures=?,category=? where filmid=?";
			String sql1="delete from film_language where film_id=?";
			String sql4="delete from film_actors where film_id=?";
			
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				//pst.setString(1, film.getTitle());
				pst.setString(1, film.getTitle());
				pst.setString(2, film.getDescription());
				pst.setDate(3, new Date(film.getRealeaseYear().getTime()));
				int language=film.getOriginalLanguage().getLanguage_Id();
				pst.setInt(4, language);
				pst.setDate(5, new Date(film.getRentalDuration().getTime()));
				pst.setInt(6, film.getLength());
				pst.setDouble(7,film.getReplacementCost());
				
				pst.setInt(8,film.getRatings());
				pst.setString(9,film.getSpecialFeatures());
				int category=film.getCategory().getCategory_Id();
				pst.setInt(10,category);
				pst.setInt(11, id);
				
				count=pst.executeUpdate();
				
				
				//delete from film_language
				PreparedStatement pst1=con.prepareStatement(sql1);
				pst1.setInt(1, id);
			    count=pst1.executeUpdate();
			    
			  //delete from film_actors
				PreparedStatement pst4=con.prepareStatement(sql4);
				pst4.setInt(1, id);
			    count=pst4.executeUpdate();
			    
			    //insert into film_language
			  //insert into film_languages
				String sql2="insert into film_language values(?,?)";
				PreparedStatement pst2=con.prepareStatement(sql2);
			     List<Language> lang=film.getLanguages();
			     System.out.println(lang);
				for(Language lang1:lang){
				pst2.setInt(1, id);
				pst2.setInt(2,lang1.getLanguage_Id());
			    count=pst2.executeUpdate();
				}
			    
				String sql3="insert into film_actors values(?,?)";
				PreparedStatement pst3=con.prepareStatement(sql3);
			    List<Actor> actor=film.getActors();
				for(Actor act1:actor){
				pst3.setInt(1, id);
				pst3.setInt(2,act1.getActor_Id());
				 count=pst3.executeUpdate();
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


			return count;
		}

		public List<Film> searchFilm(Film film) {
			Connection con=getConnection();
			int count=0;
			String sql="select * from FILM where ";
			ArrayList<Film> films=new ArrayList<Film>();
			System.out.println(film);
			if(film!=null)
			{
				if(film.getFilm_Id()>0)
				{
					
					sql+="filmid="+film.getFilm_Id();
					
					count=1;
				}
				
				if(film.getTitle()!=null)
				{
					if(count==1)
					{
						sql+=" and title='"+film.getTitle()+"'";
					}
					else
					{
						sql+=" title='"+film.getTitle()+"'";
					}
					count=2;
				}
			

				if(film.getRatings()>0)
				{
					if(count==1||count==2)
					{
						sql+=" and ratings="+film.getRatings();
					}
					else
					{
						sql+=" ratings="+film.getRatings();
					}
					count=3;
					
				}
				if(film.getActors()!=null)
				{
					Actor actor=new Actor();
				//	Set<Actor> act=film.getActors();
					List<Actor> act = film.getActors();
					for(Actor a:act)
						actor=a;
					if(count==1||count==2||count==3)
					{
						sql+=" and filmid In(Select film_id from film_actors where actor_id="+actor.getActor_Id()+")";
						
					}else
					{
					sql+=" filmid In(Select film_id from film_actors where actor_id="+actor.getActor_Id()+")";
					}
					count=4;
				}
				if(film.getLanguages()!=null)
				{
					Language lang=new Language();
					List<Language> langs=film.getLanguages();
				
					for(Language l:langs)
						lang=l;
					if(count==1||count==2||count==3||count==4)
					{
						sql+=" and( filmid In(Select film_id from film_language where language_id="+lang.getLanguage_Id()+") or filmid In( Select filmid from film where OriginalLanguage="+lang.getLanguage_Id()+"))";
						
					}else
					{
					sql+=" ( filmid In(Select film_id from film_language where language_id="+lang.getLanguage_Id()+") or filmid In (Select filmid from film where OriginalLanguage="+lang.getLanguage_Id()+"))";
					
					}
					count=5;
				}
			
				 
				if(film.getRealeaseYear()!=null)
				{
					if(count==1||count==2||count==3||count==4||count==5)
					{
						sql+=" and releaseYear='"+new java.sql.Date(film.getRealeaseYear().getTime())+"'";
					}
					else
					{
						sql+="  releaseYear='"+new java.sql.Date(film.getRealeaseYear().getTime())+"'";
					}
					count=6;
				}
				System.out.println(sql);
				try {
					PreparedStatement pst=con.prepareStatement(sql);
					ResultSet rs=pst.executeQuery();
				
					while(rs.next())
					{
						Film film1=new Film();
						film1.setFilm_Id(rs.getInt(1));
						
						film1.setTitle(rs.getString(2));
						film1.setDescription(rs.getString(3));
						
						film1.setRealeaseYear(rs.getDate(4));
						
						String subsql;
						subsql="select NAME from language where languageID="+rs.getInt(5);
						PreparedStatement pst1=con.prepareStatement(subsql);
						ResultSet rs3=pst1.executeQuery();
						Language lang=new Language();
						if(rs3.next())
						{
							lang.setLanguage_Id(rs.getInt(5));
							lang.setLanguage_Name(rs3.getString(1));
						}
						film1.setOriginalLanguage(lang);
						film1.setRentalDuration(rs.getDate(6));
						film1.setLength(rs.getInt(7));
						film1.setReplacementCost(rs.getInt(8));
						film1.setRatings(rs.getInt(9));
						film1.setSpecialFeatures(rs.getString(10));
						
						subsql="select NAME from category where categoryID="+rs.getInt(11);
						PreparedStatement pst3=con.prepareStatement(subsql);
					    rs3=pst3.executeQuery();
						if(rs3.next())
						{
							Category cat=new Category();
							cat.setCategory_Id(rs.getInt(11));
							cat.setCategory_Name(rs3.getString(1));
							film1.setCategory(cat);
						}
						
						subsql="select language_id from film_language where film_id="+rs.getInt(1);
						System.out.println(rs.getInt(1));
						pst3=con.prepareStatement(subsql);
					    rs3=pst3.executeQuery();
					    List<Language> languages=new ArrayList<>();
						while(rs3.next())
						{
													
							String subsql1="select NAME from language where languageID="+rs3.getInt(1);
							PreparedStatement pst2=con.prepareStatement(subsql1);
							ResultSet rs1=pst2.executeQuery();
							while(rs1.next()){
								Language langs=new Language();
								langs.setLanguage_Id(rs3.getInt(1));
								langs.setLanguage_Name(rs1.getString(1));
								languages.add(langs);
								
							}
						}
						film1.setLanguages(languages);
						subsql="select actor_id from film_actors where film_id="+rs.getInt(1);
					
						pst3=con.prepareStatement(subsql);
					    rs3=pst3.executeQuery();
					   // Set<Actor> actors=new HashSet<>();
					    List<Actor> actors = new ArrayList<>();
						while(rs3.next())
						{
							String subsql1="select firstName,lastName from actor where actor_id="+rs3.getInt(1);
							PreparedStatement pst2=con.prepareStatement(subsql1);
							ResultSet rs1=pst2.executeQuery();
							while(rs1.next()){
								Actor actr=new Actor();
								actr.setActor_Fname(rs1.getString(1));
								actr.setActor_Lname(rs1.getString(2));
								actr.setActor_Id(rs3.getInt(1));
								actors.add(actr);
								
							}
						}
						film1.setActors(actors);
						film1.setLanguages(languages);
						System.out.println(film1);
						films.add(film1);
				} }catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
				
				
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
			
			return films;
			
		}
	
	

}
