package com.flp.fms.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.service.ActorServiceImpl;

/**
 * Servlet implementation class DeleteActorServlet
 */
public class DeleteActorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();

		/*out.println("<head>");
		out.print("<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
		out.println("</head>");
		out.print("<body>");
		out.print("Add");
		out.print("</body>");*/

		/*FilmServiceImp filmservice=new FilmServiceImp();
		List<Film> film=filmservice.getAllFilms();*/
		ActorServiceImpl actorService=new ActorServiceImpl();
		List<Actor> actor=actorService.getActorList();                     




		out.println("<head>");
		out.print("<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
		out.println("</head>");


		out.println("<body>"
				+ "<h2 align='center'>List Of Films</h2>"
				+ "<center>"
				+ "<table border=2px colspan=2px>"
				+ "<tr>"
				+ "<th>Actor Id</th>"
				+ "<th>First Name</th>"
				+ "<th>Last Name</th>"
				+ "<th>Delete<th>"
				+ "</tr>");
		for(Actor actor1:actor){

			out.println("<tr>");
			out.println("<td>"+actor1.getActor_Id()+"</td>");
			out.println("<td>"+actor1.getActor_Fname()+"</td>");
			out.println("<td>"+actor1.getActor_Lname()+"</td>");
			out.print("<td><a href='DeleteActorServlet1?id="+actor1.getActor_Id()+"'><h5 style='color:#E45E9D;'>Delete</h5></a></td>");

			out.println("</tr>");
		}
		out.println("</table></center></body>");
	}

}
