package com.flp.fms.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.service.ActorServiceImpl;

/**
 * Servlet implementation class ModifyActorServlet1
 */
public class ModifyActorServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		int actorId=Integer.parseInt(request.getParameter("id"));
		System.out.println(actorId);
		ActorServiceImpl actorService=new ActorServiceImpl();
		Actor actor=actorService.getActorByID(actorId);
		
		
		out.print("<html>");
		out.print("<head>");
		out.print("<script type='text/javascript' src='scripts/validate.js'></script>"
				+ " <link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
		out.print("</head>");
		
		out.print("<body>");
		out.print("<form name='actor' method='post' action='ModifyActorServlet2'>");
		out.print("<h1 align='center'>Fill The Details of Actor</h1>");
		out.println("<center> "
				+ "<table>"
				+ "<tr>"
				+ "<td><label>First Name</label></td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='aFName' onmouseout='return validateDetails()' value='"+actor.getActor_Fname()+"'>"
				+ "<div id='fNameErr'></div>"
				+ "</td>"
				+ "</tr>");
		out.println("<tr>"
				+ "<td><label>Last Name</label></td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='aLName' onmouseout='return validateDetails()' value='"+actor.getActor_Lname()+"'>"
				+ "<div id='lNameErr'></div>"
				+ "</td>"
				+ "</tr>"
				+ " <tr><td><input type='hidden' name='actor_id' value='"+actorId+"'");
		
		out.print("<tr><td></td>"
				+ "<td><input type='submit' value='Submit'</td>"
				+ "</tr>");
				
		out.print("</table>"
				+ "</center>"
				+ "</body>"
				+ "</html");
		
	}

}
