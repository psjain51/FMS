package com.flp.fms.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.service.FilmServiceImp;

/**
 * Servlet implementation class DeleteServlet1
 */
public class DeleteServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteServlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		int id=Integer.parseInt(request.getParameter("id"));
		FilmServiceImp filmservice=new FilmServiceImp();
		int count=filmservice.removeFilm(id);
		
		
		out.println("<head>");
		out.print("<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
		out.println("</head>");
		out.print("<body>");
		//System.out.println(count);
		if(count>0){
			request.getRequestDispatcher("DeleteServlet").forward(request, response);
		}
		out.print("</body>");
		
		
		
		
	}

}
