package com.flp.fms.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.service.ActorServiceImpl;
import com.flp.service.FilmServiceImp;
import com.flp.service.IActorService;
import com.flp.service.IFilmService;

/**
 * Servlet implementation class SeachPageServlet
 */
public class SeachPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService filmService =new FilmServiceImp();
		IActorService actorService=new ActorServiceImpl();
		List<Language> languages=filmService.getLanguage();
		List<Actor>actors=actorService.getActorList();
		List<Category>category=filmService.getCategory();
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head><title>Search Film</title>");
		out.println("<script type='text/javascript' src='scripts/validate.js'></script>"
				+"<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>"
				+ "<script src='//code.jquery.com/jquery-1.10.2.js'></script>"
				+"<script src='//code.jquery.com/ui/1.11.4/jquery-ui.js'></script>"
				
				+ " <link rel='stylesheet' type='text/css' href='css/mystyles.css'>"
				/*+ "<link rel='stylesheet' type='text/css' href='css/jquery-ui-1.9.2.custom.css'>"
				+ "<link rel='stylesheet' type='text/css' href='css/jquery-ui-1.9.2.custom.min.css'>"
				+ "<link rel='stylesheet' type='text/css' href='css/jquery-ui-1.9.2.custom.min.css'>"*/
				+ "<script type='text/javascript' src='scripts/jquery-1.8.3.js'></script>"
				+ "<script type='text/javascript' src='scripts/jquery-ui-1.9.2.custom.js'></script>"
				+ "<script type='text/javascript' src='scripts/jquery-ui-1.9.2.custom.min.js'></script>"
				/*+ "<script type='text/javascript' src='scripts/dateSelector.js'></script>");*/
		+"<!-- Javascript -->"
		+"    <script>"
		
		+"       $(function() {"
		  +"       $( '#datepicker1' ).datepicker({maxDate:'0', dateFormat:'dd-M-yy'});"
		    +"    $( '#datepicker1' ).datepicker('show');"
		      +"});"
		       + "</script>");
		
		out.println("</head>"
		+"<body>");
		
		out.println("<form name='searchForm' action='DisplayFilmServlet'");
		out.println("<div>");
		out.println("<fieldset>"
				+ "<legend align='top'>Search Page</legend><table>");
		
		out.println("<tr>"+ "<td>");
		out.println("By FilmId:<input type='textbox' name='byId'/> ");
		out.println("</td>"+ "</tr>");
		
		out.println("<tr>"+ "<td>");
		out.println("By Rating:<input type='textbox' name='byRating'/> ");
		out.println("</td>"+ "</tr>");
		
		out.println("<tr>"+"<td>Release Date:<input type='text' id='datepicker1' name='releasedate' size='20'>"
	    +"</td> "+"	</tr>");
		
		out.println("<tr>"+ "<td>");
	    out.println("By Title:<input type='textbox' name='byTitle'/> ");
		out.println("</td>"+ "</tr>"
	    
		+ "<tr>" + "<td>");
		out.println("By Language:<select name='byLanguage'>"
	    +"<option value='0'>--Select--</option>");
	    for(Language lang:languages){
	    out.println("<option value='"+ lang.getLanguage_Id()+"'>"
	    +lang.getLanguage_Name()+ "</option>");	
		   }
	    out.println("</select>");
	    out.println("</td></tr>");
	    
	
		out.println("<tr><td>");
		out.println("By Actor:<select name='byActor'>"
		+ "<option value='0'>--Select--</option>");
		for(Actor act: actors)
		{
		out.println("<option value='"+act.getActor_Id()+"'>"
		+act.getActor_Fname()+" "+act.getActor_Lname()
		+"</option>");
		}
		
		out.println("</select>");
		out.println("</td>");
		out.println("</tr>"
				+ "<tr>"
				+ "<td>"
				+ "<input type='submit' value='search' name='search'>"
				+ "</td>"
				+ "</tr>"
				);

		out.println("</table>");
		out.println("</div>");
	
	
	
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}

}
