function validateDetails(){
	var flag=true;
	var title=film.title.value;
	/*var upass=myForm.upwd.value;*/

	var letters = /^[A-Za-z0-9]+$/;  
	if(title==null|| title=="" || title.match(letters))
		{
		document.getElementById("titleErr").innerHTML="*Please enter title staring with alphabet";
		flag=false;
		}
	else
		document.getElementById("titleErr").innerHTML="";
		
	
	
	var desc=film.desc.value;
	if(desc==null|| desc=="")
	{
	document.getElementById("descErr").innerHTML="*Please enter description for the film";
	flag=false;
	}
else
	document.getElementById("descErr").innerHTML="";
	
	
	
	 
	
	var rentDur=film.rentD.value;
	 var relDate=film.release.value;
	 if(rentDur>relDate)
		 document.getElementById("rentDErr").innerHTML="";
	 else
		 {
		 document.getElementById("rentDErr").innerHTML="*Rental Duration date should not be before release date";
			flag=false;
		 }
	 
	 var length=film.length.value;
	 
	 if(length>0 && length<1000)
		 document.getElementById("lengthErr").innerHTML="";
	 else{
		 document.getElementById("lengthErr").innerHTML="*Length should be in range[1-1000]";
			flag=false;
		}
	
	 var rating=film.rating.value;
	 if(rating.selectedIndex==0){
		 document.getElementById("ratingErr").innerHTML="*Please select the rating";
			flag=false;
		 }
	 else
		 document.getElementById("ratingErr").innerHTML="";

		 
		 
		 
	 
	return flag;
}

