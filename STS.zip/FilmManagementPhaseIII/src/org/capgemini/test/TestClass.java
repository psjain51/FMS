package org.capgemini.test;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.sql.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.capgemini.dao.ActordaoImpl;
import org.capgemini.dao.FilmDaoImpl;
import org.capgemini.domain.Actor;
import org.capgemini.domain.Category;
import org.capgemini.domain.Film;
import org.capgemini.domain.Language;
import org.junit.Assert;
import org.junit.Test;

public class TestClass {

	FilmDaoImpl film_dao=new FilmDaoImpl();
	ActordaoImpl actor_dao=new ActordaoImpl();
	List<Language> testLanguageList=new ArrayList<>();
	List<Actor> testActorList=new ArrayList<>();
	List<Category> testCategoryList=new ArrayList<>();
	List<Film> testFilmList=new ArrayList<>();
	List<Film> expectedFilmList=new ArrayList<>();
	Category category=new Category();
	Set<Actor> actor_set=new HashSet<>();
	@Test
	public void testGetLanguageList() {
		
		Language language=new Language();
		testLanguageList.add(new Language(1,"English"));
		testLanguageList.add(new Language(2,"Hindi"));
		testLanguageList.add(new Language(3,"Marathi"));
		testLanguageList.add(new Language(4,"Tamil"));
		testLanguageList.add(new Language(5,"Telugu"));
		testLanguageList.add(new Language(6,"Malayalam"));
		
		Assert.assertEquals(testLanguageList, film_dao.getLanguages());
	}
	
	@Test
	public void testLanguageListIsNotNull()
	{
		assertNotNull(film_dao.getLanguages());
	}
	
	@Test
	public void testLengthOfLanguageList()
	{
		assertEquals(6, film_dao.getLanguages().size());
	}
	
	@Test
	public void testActorListIsNotNull()
	{
		assertNotNull(actor_dao.getActors());
	}
	
	
	
	@Test
	public void testGetListOfCategory() {
		
		testCategoryList.add(new Category(1,"Horror"));
		testCategoryList.add(new Category(2,"Comedy"));
		testCategoryList.add(new Category(3,"Action"));
		testCategoryList.add(new Category(4,"Animated"));
		testCategoryList.add(new Category(5,"Documentary"));
		testCategoryList.add(new Category(6,"Adventure"));
		testCategoryList.add(new Category(7,"Drama"));
		testCategoryList.add(new Category(8,"Romance"));
		
		assertEquals(testCategoryList.size(), film_dao.getCategories().size());
	}
	
	@Test
	public void testCategoryListIsNotNull()
	{
		assertNotNull(film_dao.getCategories());
	}
	
	@Test
	public void testLengthOfCategoryList()
	{
		assertEquals(8, film_dao.getCategories().size());
	}
	
		
	
	@Test
	public void testSearchById() throws ParseException
	{
		Film search_film=new Film();
		search_film.setFilm_Id(3);
	
		Film film=new Film();
		
		SimpleDateFormat df=new SimpleDateFormat("yyyyMMdd");
		java.util.Date release_parsed = df.parse("20060623");
		java.util.Date rental_parsed = df.parse("20100407");
		film.setFilm_Id(21);
		film.setTitle("Krrish");
		film.setDescription("Science fiction superhero film");
		film.setRealeaseYear(new Date(release_parsed.getTime()));
		
		
		Language original_language=new Language();
		original_language.setLanguage_Id(2);
		original_language.setLanguage_Name("Hindi");
		film.setOriginalLanguage(original_language);
		List<Language> other_languages=new ArrayList<>();
		other_languages.add(new Language(1,"English"));
		other_languages.add(new Language(5,"Telugu"));
		film.setLanguages(other_languages);
		film.setRentalDuration(new Date(rental_parsed.getTime()));
		
		actor_set.add(new Actor(1,"Hrithik","Roshan"));
		actor_set.add(new Actor(7,"Priyanka","Chopra"));
		film.setActors(actor_set);
		film.setCategory(new Category(3,"Action"));
		film.setLength(175);
		film.setReplacementCost(690000);
		film.setRatings(4);
		film.setSpecialFeatures("Visual Effects");
		expectedFilmList.add(film);
		assertFalse(expectedFilmList.equals(film_dao.searchFilm(search_film)));
	}
	
	@Test
	public void testSearchByTitle() throws ParseException
	{
		Film search_film=new Film();
		search_film.setFilm_Id(3);
	
		Film film=new Film();
		
		SimpleDateFormat df=new SimpleDateFormat("yyyyMMdd");
		java.util.Date release_parsed = df.parse("20060623");
		java.util.Date rental_parsed = df.parse("20100407");
		film.setFilm_Id(21);
		film.setTitle("Krrish");
		film.setDescription("Science fiction superhero film");
		film.setRealeaseYear(new Date(release_parsed.getTime()));
		
		
		Language original_language=new Language();
		original_language.setLanguage_Id(2);
		original_language.setLanguage_Name("Hindi");
		film.setOriginalLanguage(original_language);
		List<Language> other_languages=new ArrayList<>();
		other_languages.add(new Language(1,"English"));
		other_languages.add(new Language(5,"Telugu"));
		film.setLanguages(other_languages);
		film.setRentalDuration(new Date(rental_parsed.getTime()));
		
		actor_set.add(new Actor(1,"Hrithik","Roshan"));
		actor_set.add(new Actor(7,"Priyanka","Chopra"));
		film.setActors(actor_set);
		film.setCategory(new Category(3,"Action"));
		film.setLength(175);
		film.setReplacementCost(690000);
		film.setRatings(4);
		film.setSpecialFeatures("Visual Effects");
		expectedFilmList.add(film);
		assertFalse(expectedFilmList.equals(film_dao.searchFilm(search_film)));
	}
	
	
	@Test
	public void testGetAllFilms(){
		assertEquals(6,film_dao.getAllFilms().size());
	}
	
	
	
	
}
