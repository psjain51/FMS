package org.capgemini.dao;

import java.util.ArrayList;
import java.util.List;


import org.capgemini.domain.Category;
import org.capgemini.domain.Film;
import org.capgemini.domain.Language;



public interface IFilmDao {
	
	public List<Language> getLanguages();
	public List<Category> getCategories();
	public void addFilm(Film film);
	public ArrayList<Film> getAllFilms();
	public List<Film> searchFilm(Film film);
	public void updateFilm(Film film);
	public boolean deleteFilm(int filmid);


}
