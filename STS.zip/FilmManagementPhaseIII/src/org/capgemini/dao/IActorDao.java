package org.capgemini.dao;

import java.util.Set;

import org.capgemini.domain.Actor;

public interface IActorDao {

	public Set<Actor> getActors();
	
	public int addActor(Actor actor);
	public int removeActor(int id);

	
	
	public Actor getActorByID(int id);
	public int updateActor(Actor actor, int actorId);
}
