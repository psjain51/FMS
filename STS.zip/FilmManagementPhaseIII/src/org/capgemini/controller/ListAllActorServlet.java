package org.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.domain.Actor;
import org.capgemini.service.ActorServiceImpl;

/**
 * Servlet implementation class ListAllActorServlet
 */
public class ListAllActorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		
         ActorServiceImpl actorService=new ActorServiceImpl();
         Set<Actor> actor=actorService.getActors();                     
		
		
	

		out.println("<head>");
		out.print("<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
		out.println("</head>");
		
		
		out.println("<body>"
				+ "<h2 align='center'>List Of Films</h2>"
				+ "<center>"
				+ "<table border=2px colspan=2px>"
				+ "<tr>"
				+ "<th>Actor Id</th>"
				+ "<th>First Name</th>"
				+ "<th>Last Name</th>"
				+ "</tr>");
		for(Actor actor1:actor){
			
			out.println("<tr>");
			out.println("<td>"+actor1.getActor_Id()+"</td>");
			out.println("<td>"+actor1.getFirstName()+"</td>");
			out.println("<td>"+actor1.getLastName()+"</td>");
			
			out.println("</tr>");
		}
			out.println("</table></center></body>");
	    
	}


}
