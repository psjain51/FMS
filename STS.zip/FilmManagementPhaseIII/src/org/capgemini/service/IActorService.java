package org.capgemini.service;

import java.util.Set;

import org.capgemini.domain.Actor;

public interface IActorService {
	public Set<Actor> getActors();
	
	public int addActor(Actor actor);

	public int removeActor(int id);
	
	public Actor getActorByID(int id);
	public int updateFilm(Actor actor, int actorId);

}
