package org.capgemini.service;

import java.util.Set;

import org.capgemini.domain.Actor;

public interface IActorService {
	public Set<Actor> getActors();
}
