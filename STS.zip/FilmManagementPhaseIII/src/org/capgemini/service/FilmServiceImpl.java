package org.capgemini.service;


import java.util.List;
import java.util.Map;

import org.capgemini.dao.FilmDaoImpl;
import org.capgemini.dao.IFilmDao;
import org.capgemini.domain.Category;
import org.capgemini.domain.Film;
import org.capgemini.domain.Language;


public class FilmServiceImpl implements IFilmService{
	
	private IFilmDao filmDao=new FilmDaoImpl();

	@Override
	public List<Language> getLanguages() {
		
		return filmDao.getLanguages();
	}

	@Override
	public void addFilm(Film film) {
		
		
		filmDao.addFilm(film);
		
	}
	
	
	@Override
	public List<Film> getAllFilms() {
		
		return filmDao.getAllFilms();
	}
	
	
	@Override
	public List<Category> getCategories() {
		
		return filmDao.getCategories();
	}

	
	
	public List<Film> searchFilm(Film film){
		return filmDao.searchFilm(film);
		
	}

	@Override
	public void updateFilm(Film film) {
		 filmDao.updateFilm(film);
		
	}

	@Override
	public boolean deleteFilm(int filmid) {
		
		return filmDao.deleteFilm(filmid);
	}

	
}
