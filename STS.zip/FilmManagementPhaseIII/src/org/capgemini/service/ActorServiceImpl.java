package org.capgemini.service;



import java.util.Set;

import org.capgemini.dao.ActordaoImpl;
import org.capgemini.dao.IActorDao;
import org.capgemini.domain.Actor;



public class ActorServiceImpl implements IActorService{

	private IActorDao actorDao=new ActordaoImpl();
	
	@Override
	public Set<Actor> getActors() {
		// TODO Auto-generated method stub
		return actorDao.getActors();
	}
	
	public int addActor(Actor actor) {
		// TODO Auto-generated method stub
		return actorDao.addActor(actor);
	}
	public int removeActor(int id) {
		
		return actorDao.removeActor(id);
	}
	@Override
	public Actor getActorByID(int id) {
		// TODO Auto-generated method stub
		return actorDao.getActorByID(id);
	}
	public int updateFilm(Actor actor, int actorId) {
		
		return actorDao.updateActor(actor, actorId);
	}
	
}



