package com.flp.fms.dao;



import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmDaoImplForList implements IFilmDao{

	
	private Map<Integer, Film> film_Repository=new HashMap<>();
	

	
	
	@Override
	public List<Language> getLanguages() {
		List<Language> languages=new ArrayList<>();
		languages.add(new Language(1, "English"));
		languages.add(new Language(2, "Hindi"));
		languages.add(new Language(3, "Telugu"));
		languages.add(new Language(4, "Marathi"));
		languages.add(new Language(5, "Kannada"));
		languages.add(new Language(6, "Tamil"));
		languages.add(new Language(7, "Malayalam"));
		
  
	
	
		return languages;
	}
	
	@Override
	public List<Category> getCategories() {
		List<Category> categories=new ArrayList<>();
		categories.add(new Category(1, "Horror"));
		categories.add(new Category(2, "Drama"));
		categories.add(new Category(3, "Romance"));
		categories.add(new Category(4, "Action"));
		categories.add(new Category(5, "Adventure"));
		categories.add(new Category(6, "Documentary"));
		categories.add(new Category(7, "Comedy"));
		  
				
				
			
		
		
		return categories;
	}
	
	//CURD Operation
	@Override
	public String addFilm(Film film) {
		String str=null;
		
		if(film!=null){
		film_Repository.put(film.getFilm_Id(), film);
		str="Film added successfully";
		
		}else{
			str="Film object is null";
		}
		
		return str;
	}


	@Override
	public Map<Integer, Film> getAllFilms() {
		
		return film_Repository;
	}

	//SEARCHING FILM FROM THE REPOSITORY USING ID
			@Override
			public Film searchFilmById(int filmId) {
					
				return film_Repository.get(filmId);
			}
			
			
			//SEARCHING FILM USING TITLE
			@Override
			public Film searchFilmByTitle(String title) {
				
				Film result = null;
				
				Collection<Film> films = film_Repository.values();
				Iterator<Film> itr = films.iterator();
				
				while(itr.hasNext()){
					
					Film film = itr.next();
					if(film.getTitle().equals(title)){
						
						result = film;
						break;
					}
				}
				
				return result;
			}
			
			
			//SEARCHING FILM USING RATING
			@Override
			public List<Film> searchFilmByRating(int rating) {

				List<Film> selectedFilms = new ArrayList<>();
				
				Collection<Film> films = film_Repository.values();
				Iterator<Film> itr = films.iterator();
				
				while(itr.hasNext()){
					
					Film film = itr.next();
					
					if(film.getRatings()==rating){
						
						selectedFilms.add(film);
					}
				}
				
				
				return selectedFilms;
			}

			
			//SEARCHING FILM USING LANGUAGE
			@Override
			public List<Film> searchFilmByLanguage(Language language) {
				
				List<Film> selectedFilms = new ArrayList<>();
				
				Collection<Film> films = film_Repository.values();
				Iterator<Film> itr = films.iterator();
				
				while(itr.hasNext()){
					
					Film film = itr.next();
					
					//if original language is same as entered language
					if(film.getOriginalLanguage().getLanguage_Id() == language.getLanguage_Id()){
						
						selectedFilms.add(film);
					}
					
					//if film is released in entered language
					else{
						
						List<Language> languages = new ArrayList<>();
						languages = film.getLanguages();
						
						for(Language lang : languages){
							
							if(lang.getLanguage_Id()==language.getLanguage_Id()){
								
								selectedFilms.add(film);
							}
						}
					}
				
				}
				
				return selectedFilms;
			}
				
			
			
			//SEARCHING FILM USING ACTOR
			@Override
			public List<Film> searchFilmByActor(Actor actor) {
				
				List<Film> selectedFilms = new ArrayList<>();
				
				Collection<Film> films = film_Repository.values();
				Iterator<Film> itr = films.iterator();
				
				while(itr.hasNext()){
					
					Film film = itr.next();
					Set<Actor> actors = new HashSet<>();
					actors = film.getActors();
					
					for(Actor act : actors){
						
						if(act.getActor_Id()==actor.getActor_Id()){
							
							selectedFilms.add(film);
						}
						
					}
				}
				
				
				return selectedFilms;
			}

			
					
			//FUNCTION TO REMOVE FILM BY ID
			@Override
			public void removeFilmById(int filmId) {
				
				film_Repository.remove(filmId);
				
			}

			//FUNCTION TO REMOVE FILM BY TITLE
			@Override
			public void removeFilmByTitle(String title) {
				
				Collection<Film> allFilms = film_Repository.values();
				Iterator<Film> itr = allFilms.iterator();
				
				int filmId=0;
				
				while(itr.hasNext()){
					
					Film film = itr.next();
					
					if(film.getTitle().equals(title)){
						
						filmId = film.getFilm_Id();
						break;
					}
				}
				
				film_Repository.remove(filmId);	
			}
			

			
			//FUNCTION TO REMOVE FILM BY RATING
			@Override
			public void removeFilmByRating(int rating) {
				
				Collection<Film> allFilms = film_Repository.values();
				Iterator<Film> itr = allFilms.iterator();
				
				Set<Integer> selectedFilmIds = new HashSet<>();
				
				while(itr.hasNext()){
					
					Film film = itr.next();
					
					if(film.getRatings() == rating){
						
						selectedFilmIds.add(film.getFilm_Id());	
					}
				}
				
				for(Integer filmId : selectedFilmIds){
					
					film_Repository.remove(filmId);
				}
			}

			
			//FUNCTION TO REMOVE FILM BY ACTOR
			@Override
			public void removeFilmByActor(Actor actor) {
								
				Collection<Film> films = film_Repository.values();
				Iterator<Film> itr = films.iterator();
				
				Set<Integer> selectedFilmIds = new HashSet<>();
				
				while(itr.hasNext()){
					
					Film film = itr.next();
					
					//getting the name of all actors in the film
					Set<Actor> actors = new HashSet<>();
					actors = film.getActors();
					
					for(Actor act : actors){
						
						if(act.getActor_Id() == actor.getActor_Id()){
							
							selectedFilmIds.add(film.getFilm_Id());
						}
						
					}
				}
				
				for(Integer filmId : selectedFilmIds){
					
					film_Repository.remove(filmId);
				}

			}

			
			//FUNCTION TO UPDATE FILM
			@Override
			public String updateFilm(Film film) {
				String str=null;
				if(film!=null){
				addFilm(film);
				str="Film updated successfully";
				System.out.println(str);
				}else{
					str="Film updated successfully";
					
				}
				return str;
			}

			
}


