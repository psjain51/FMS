package com.flp.fms.service;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;

import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.Actor;


public class ActorDaoImplForDB implements IActorDao{
	
public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/fms","root","Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return connection;
	}
	

	@Override
	public Set<Actor> getActors() {
		
		Set<Actor> actors=new HashSet<>();
		 Connection con=getConnection();
			
			String sql="select actor_id,firstName,lastName from Actors";
			
			try {
				Statement stmt=con.createStatement();
				
				ResultSet rs=stmt.executeQuery(sql);
				
				while(rs.next()){
					
					actors.add(new Actor(rs.getInt(1), rs.getString(2), rs.getString(3)));
					
				}
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
		
		return actors;
	}

}