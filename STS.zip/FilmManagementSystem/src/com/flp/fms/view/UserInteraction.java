package com.flp.fms.view;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.util.Validate;

public class UserInteraction {
	
	Scanner sc=new Scanner(System.in);
	
	//Return fully qualified film object
	public Film addFilm(List<Language> languages, List<Category> categories, Set<Actor> actors){
		
		//Create Film Object
		Film film=new Film();
		boolean flag=true;
		
		//Get Title and validate it
		String title=null;
		do{
		System.out.println("Enter Film Title");
		title=sc.nextLine();
		flag=Validate.isValidTitle(title);
			if(!flag)
				System.out.println("Invalid Title. Please Enter Valid Title!");
		}while(!flag);
		film.setTitle(title);
		
		//TO GET FILM DESCRIPTION
		System.out.println("enter film description: ");
		film.setDescription(sc.nextLine());
		
		//Release Date Validation
		String releaseDate;
		boolean date_flag=false;
		Date release_Date=null;
		do{
			
			//Verify Date Format
			do{
				System.out.println("Enter Release Date:");
				releaseDate=sc.next();
				flag=Validate.isValidDate(releaseDate);
				if(!flag)
					System.out.println("Please enter date in this Format(dd-MMM-yyyy)!");
			}while(!flag);
			
			//Verifies Release Date  
			Date today=new Date();
			release_Date=new Date(releaseDate);
			if(release_Date.before(today)|| release_Date.equals(today))
				date_flag=true;
		
			if(!date_flag)
				System.out.println("Invalid Date! Date should be current date or Past Date!");
		}while(!date_flag);
		film.setRealeaseYear(release_Date);
		
		//Verify film length
		int length;
		do{
			System.out.println("Enter film length:");
			length=sc.nextInt();
			flag=Validate.isValidLength(length);
			if(!flag){
				System.out.println("Invalid entry. Please Try again");
			}
			}while(!flag);
			film.setLength(length);
		
		//Verify film ratings
		int ratings;
		do{
			System.out.println("Enter film ratings:");
			ratings=sc.nextInt();
			flag=Validate.isValidRatings(ratings);
			if(!flag){
				System.out.println("Invalid entry. Please Try again");
			}
			}while(!flag);
			film.setRatings(ratings);	
		
		//Verify rental date
		String rental;
		date_flag=false;
		Date rentalDuration=null;
		do{
			
			//Verify Date Format
			do{
				System.out.println("Enter Rental Date:");
				rental=sc.next();
				flag=Validate.isValidDate(rental);
				if(!flag)
					System.out.println("Please enter date in this Format(dd-MMM-yyyy)!");
			}while(!flag);
			
			//Verifies Rental Date  
			Date today=new Date();
			rentalDuration=new Date(rental);
			if(rentalDuration.after(release_Date))
				date_flag=true;
		
			if(!date_flag)
				System.out.println("Invalid Date! Date should be Future Date!");
		}while(!date_flag);
		film.setRentalDuration(rentalDuration);
		
		//Verify Replacement Cost
		double replacementCost;
		do{
			System.out.println("Enter replacement cost:");
			replacementCost=sc.nextDouble();
			flag=Validate.isValidReplacementCost(replacementCost);
			if(!flag){
				System.out.println("Invalid entry. Please Try again");
			}
			
		}while(!flag);
		film.setReplacementCost(replacementCost);
		
		
		//Choose Language
		System.out.println("Choose Original Language");
		Language language= addLanguage(languages);
		film.setOriginalLanguage(language);
		
		
		//Add all languages
		List<Language> languages2=new ArrayList<>();
		String choice;
		boolean flag_langs;
		do{
			System.out.println("Choose All Languages for the Film:");
			Language language1= addLanguage(languages);
			
			
			flag_langs=Validate.checkDuplicateLanguage(languages2, language1);
			if(!flag_langs)
				languages2.add(language1);
			else
				System.out.println("Language already Exists. Please try other languages!");
			
			
			System.out.println("Wish to add More Languages?[y|n]");
			choice=sc.next();
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		film.setLanguages(languages2);
		
		//Choose Category
				System.out.println("Choose Category");
				Category category= selectCategory(categories);
				film.setCategory(category);
		
				//TO GET SPECIAL FEATURES
				System.out.println("enter special features: ");
				film.setSpecialFeatures(sc.nextLine());
		
		//Add all Actors
		
		Set<Actor> actors2=new HashSet<>();
		do{
			System.out.println("Choose All Actors for the Film:");
			Actor actor=addActor(actors);
			actors2.add(actor);
			
			System.out.println("Wish to add More Actors?[y|n]");
			choice=sc.next();
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		film.setActors(actors2);
		
		
		
		
		return film;
	}
	
	
	
	
	
	//Choose Valid Language Object from the list of Languages
	public Language addLanguage(List<Language>  languages){
		
		Language sel_language=null;
		boolean flag;
		do{	
			//Print Language Details
			for(Language language:languages)
				System.out.println(language.getLanguage_Id() + "\t" + language.getLanguage_Name());
			
			System.out.println("Choose the Language:");
			int option=sc.nextInt();
			
			flag=false;
			
			//Check the Language Object
			for(Language language: languages)
			{
				if(option==language.getLanguage_Id())
				{
					sel_language=language;
					flag=true;
					break;
				}
			}
			
			//Print Error Message
			if(!flag)
				System.out.println("Please select valid Language Id");
		}while(!flag);	
		
		return sel_language;
	}
	
public Category selectCategory(List<Category>  categories){
		
		Category sel_category=null;
		boolean flag;
		do{	
			//Print Category Details
			for(Category category:categories)
				System.out.println(category.getCategory_Id() + "\t" + category.getCategory_name());
			
			System.out.println("Choose the Category:");
			int option=sc.nextInt();
			
			flag=false;
			
			//Check the Category Object
			for(Category category:categories)
			{
				if(option==category.getCategory_Id())
				{
					sel_category=category;
					flag=true;
					break;
				}
			}
			
			//Print Error Message
			if(!flag)
				System.out.println("Please select valid category!");
		}while(!flag);	
		
		return sel_category;
	}
	
	//Choose Valid Actor Object from the list of Actors
	public Actor addActor(Set<Actor> actors){
		
		Actor sel_actor=null;
		boolean flag=false;
		
		do{	
		for(Actor actor:actors)
			System.out.println(actor.getActor_Id() + "\t" + actor.getFirstName() + "\t" + actor.getLastName());
		
		System.out.println("Choose the Actor:");
		int option=sc.nextInt();
		
		flag=false;
		
		//Check the Actor Object
		for(Actor actor: actors)
		{
			if(option==actor.getActor_Id())
			{
				sel_actor=actor;
				flag=true;
				break;
			}
		}
			
		
		//Print Error Message
		if(!flag)
			System.out.println("Please select valid Actor Id");
		}while(!flag);	
		
		return sel_actor;
	}





	public void getAllFilm(Collection<Film> lst) {
		
		if(lst.isEmpty())
			System.out.println("No Film Exists!");
		
		else{
			
			System.out.println("FILM ID"+ "\t" + " TITLE" + "\t" + "DESCRIPTION" +"\t"
				+ "RELEASE_YEAR" + "\t" + "ORIGINAL_LANGUAGE" + "\t" + "OTHER_LANGUAGES" + "\t"
				+ "RENTAL_DURATION"	+ "\t" + "LENGTH" + "\t" + "REPLACEMENT_COST" + "\t"
				+ "RATING" + "\t" + "SPECIAL_FEATURES" + "\t" + "ACTORS" + "\t" + "CATEGORY");
					
					
			for(Film film: lst){
						
				printFilm(film);
			}
		}
		
	}
	
	
	//FUCTION TO PRINT A FILM
			public void printFilm(Film film){
				
				
				if (film!=null) {
					
					String otherLanguages = "";
					String allActors = "";
					//getting the name of all languages in which film is released
					for (Language language : film.getLanguages()) {

						otherLanguages = otherLanguages + language.getLanguage_Name() + ", ";
					}
					//getting the name of all the actors in the film
					for (Actor actor : film.getActors()) {

						allActors = allActors + actor.getFirstName() + " " + actor.getLastName() + ", ";
					}
					System.out.println("\n" + film.getFilm_Id() + "\t" + film.getTitle() + "\t" + film.getDescription() + "\t"
							+ film.getRealeaseYear() + "\t" + film.getOriginalLanguage().getLanguage_Name() + "\t"
							+ otherLanguages + "\t" + film.getRentalDuration() + "\t" + film.getLength() + "\t"
							+ film.getReplacementCost() + "\t" + film.getRatings() + "\t" + film.getSpecialFeatures() + "\t"
							+ allActors + "\t" + film.getCategory().getCategory_name());
				}
				
				else
					System.out.println("Film does not exist!");
			
			
			}
	
	//FUNCTION TO PROMPT THE USER TO ENTER FILM ID
			public int readFilmId(){
				
				System.out.println("enter film id");
				return sc.nextInt();
			}
			
			//FUNCTION TO PROMPT THE USER TO ENTER FILM TITLE
			public String readTitle(){
					
				System.out.println("enter film title");
				String title = sc.nextLine();
				return title;
			}
			//FUNCTION TO PROMPT THE USER TO ENTER ACTOR FIRST NAME
			public String readFirstName(){
					
				System.out.println("enter first name of Actor");
				return sc.next();
			}
			
			
			//FUNCTION TO PROMPT THE USER TO ENTER ACTOR LAST NAME
			public String readLastName(){
						
				System.out.println("enter Last name of Actor");
				return sc.next();
			}
			
			//FUNCTION TO PROMPT THE USER TO ENTER FILM RATING
			public int readRating(){
						
				System.out.println("enter film rating");
				return sc.nextInt();
			}
}
