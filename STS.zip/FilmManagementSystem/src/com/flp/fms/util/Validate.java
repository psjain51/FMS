package com.flp.fms.util;

import java.util.Iterator;
import java.util.List;

import com.flp.fms.domain.Language;

public class Validate {

	public static boolean isValidTitle(String title){
		return title.matches("[A-Za-z0-9.,! ]+");
	}
	
	public static boolean isValidDate(String myDate){
		return myDate.matches("[0123][0-9]-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-[12][890]\\d{2}");
	}
	
	public static boolean isValidLength(int length){
		if(length>0 && length<=1000){
			return true;
		}
		else{
			return false;
		}
	}
	
	public static boolean isValidRatings(int ratings){
		if(ratings>0 && ratings<6){
			return true;
		}
		else{
			return false;
		}
	}
	
	
	public static boolean isValidReplacementCost(double rc){
		if(rc>0){
			return true;
		}
		else{
			return false;
		}
	}
	
	
	//Check Duplicate Language in the List
	public static boolean checkDuplicateLanguage(List<Language> languages,Language language){
		boolean flag=false;
		
		Iterator<Language> it= languages.iterator();
		if(languages.isEmpty())
		{
			flag=false;
		}else{
			while(it.hasNext()){
				Language language2=it.next();
				if(language.equals(language2))
				{
					flag=true;
					break;
				}
			}
		}
		return flag;
	}
}
