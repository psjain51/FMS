
      // Form validation code will come here.
function istitlevalidate()  
{   
		var filmtitle=myForm.title.value;
		
		var letters = /^[A-Za-z]+$/;  
		if(filmtitle.match(letters))  
		{  
			document.getElementById("titleErr").innerHTML="";
			return true;  
		}  
		else  
		{  
			document.getElementById("titleErr").innerHTML="*Title should only contain alphabet"; 
			filmtitle.focus();  
			return false;  
		}  
}

function isdescriptionvalidate()  
{   var alphanumeric=/^([0-9]|[a-z])+([0-9a-z]+)$/;
		
		if(myForm.description.value.match(alphanumeric))  
		{  
			document.getElementById("descriptionErr").innerHTML="";
			return true;  
		}  
		else  
		{  
			document.getElementById("descriptionErr").innerHTML="*Description cannot be empty"; 
			 document.myForm.description.focus();  
			return false;  
		}  
}

function isspecialvalidate()  
{   var alphanumeric=/^([0-9]|[a-z])+([0-9a-z]+)$/;
		
		if(myForm.special_feature.value.match(alphanumeric))  
		{  
			document.getElementById("special_featureErr").innerHTML="";
			return true;  
		}  
		else  
		{  
			document.getElementById("special_featureErr").innerHTML="*Special Feature cannot be empty"; 
			 document.myForm.special_feature.focus();  
			return false;  
		}  
}
function isValidRental()
{
var release=myForm.release_date.value;
var rental=myForm.rental_duration.value;

if(rental<release)
	{
	document.getElementById("rentalErr").innerHTML="*Rental date cannot be greater than release year"; 
	 document.myForm.rental_duration.focus(); 
	 return false;
	}
else
	{
	document.getElementById("rentalErr").innerHTML=""; 
	return true;
	}
}
function isreplacementvalidate()  
{   var numbers = /^[0-9]+$/;
		
		if(myForm.replacement_cost.value.match(numbers))  
		{  
			document.getElementById("replacement_costErr").innerHTML="";
			return true;  
		}  
		else  
		{  
			document.getElementById("replacement_costErr").innerHTML="*replacement cost should be number"; 
			 document.myForm.replacement_cost.focus();  
			return false;  
		}  
}

function isValidLength()  
{  
   var numbers = /^[0-9]+$/;  
   if(myForm.length.value.match(numbers))  
   {  
	   document.getElementById("lengthErr").innerHTML="";
  
   return true;  
   }  
   else  
   {  
	   document.getElementById("lengthErr").innerHTML="*length should only contain numbers";   
	   document.myForm.length.focus();   
   return false;  
   }  
}   





