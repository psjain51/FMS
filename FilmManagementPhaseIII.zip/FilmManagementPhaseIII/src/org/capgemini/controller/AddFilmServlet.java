package org.capgemini.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.domain.Actor;
import org.capgemini.domain.Category;
import org.capgemini.domain.Film;
import org.capgemini.domain.Language;
import org.capgemini.service.FilmServiceImpl;
import org.capgemini.service.IFilmService;


/**
 * Servlet implementation class AddFilmServlet
 */
public class AddFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        IFilmService filmService=new FilmServiceImpl();
		
		Film film=new Film();
		
		film.setTitle(request.getParameter("title"));
		film.setDescription(request.getParameter("description"));
		film.setLength(Integer.parseInt(request.getParameter("length")));
		film.setReplacementCost(Integer.parseInt(request.getParameter("replacement_cost")));
		film.setSpecialFeatures(request.getParameter("special_feature"));
		
		String[] langs=request.getParameterValues("lang");	
		List<Language> langList = new ArrayList<Language>();
		for(String str:langs){
			Language language=new Language();
			language.setLanguage_Id(Integer.parseInt(str));
			langList.add(language);
		}
		film.setLanguages(langList);
		
		Language language1=new Language();
		language1.setLanguage_Id(Integer.parseInt(request.getParameter("originallang")));
		film.setOriginalLanguage(language1);
		
		Category category=new Category();
		category.setCategory_Id(Integer.parseInt(request.getParameter("category")));
		film.setCategory(category);
		
		String[] actors=request.getParameterValues("actor");
		Set<Actor> act=new HashSet<Actor>();
		for(String str:actors){
			Actor actor=new Actor();
			actor.setActor_Id(Integer.parseInt(str));
			act.add(actor);
		}
		film.setActors(act);
		
		film.setRatings(Integer.parseInt(request.getParameter("ratings")));
		
		String ry=request.getParameter("release_date");
		Date regdate=new Date(ry);
		film.setRealeaseYear(regdate);
		
		String rd=request.getParameter("rental_duration");
		Date rendate=new Date(rd);
		film.setRentalDuration(rendate);
		
		System.out.println(film);
		
		//Persist film Object into DataBase
		filmService.addFilm(film);
		
		//response.sendRedirect("SaveCustomerServlet");
		request.getRequestDispatcher("../FilmFormServlet").forward(request, response);
	}

}
