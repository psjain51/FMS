package org.capgemini.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.service.FilmServiceImpl;
import org.capgemini.service.IFilmService;

/**
 * Servlet implementation class DeleteServlet
 */
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String filmid=request.getParameter("filmid");
		IFilmService filmService=new FilmServiceImpl();
		boolean flag=filmService.deleteFilm(Integer.parseInt(filmid));
		if(flag){
			request.getRequestDispatcher("DeletePageServlet").forward(request, response);
		}
	

}}
