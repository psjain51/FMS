package org.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.domain.Actor;
import org.capgemini.domain.Language;
import org.capgemini.service.IActorService;
import org.capgemini.service.ActorServiceImpl;
import org.capgemini.service.IFilmService;
import org.capgemini.service.FilmServiceImpl;

/**
 * Servlet implementation class SearchFilm
 */
public class SearchPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	PrintWriter out=response.getWriter();
	IFilmService film_service=new FilmServiceImpl ();
	IActorService actor_service=new ActorServiceImpl();
	List<Language> languages=film_service.getLanguages();
	Set<Actor> actors=actor_service.getActors();
	out.println("<html>");
	out.println("<head><title>Search Film</title>");
	out.println("</head>");
	out.println("<body>");
	out.println("<form name='searchForm' method='post' action='SearchServlet'>");
	out.println("<div>");
	out.println("By Id:<input type='textbox' name='byId'/> ");
	out.println("<br>");
	out.println("<br>");
	out.println("By Title:<input type='textbox' name='byTitle'/> ");
	out.println("<br>");
	out.println("<br>");
	out.println("By Language:<select name='ByLanguage'> ");
	  for(Language lang:languages){
			out.println("<option value='"+ lang.getLanguage_Id()+"'>"
					+lang.getLanguage_Name()+ "</option>");	
	   }
	out.println("</select>");
	out.println("<br>");
	out.println("<br>");
	out.println("<br>");
	out.println("By Actor:<select name='byActor'>");
	for(Actor act: actors)
	{
		out.println("<option value='"+act.getActor_Id()+"'>"
				+act.getFirstName()+" "+act.getLastName()
				+"</option>");
		
	}
	out.println("</select>");
	out.println("</div>");
	out.println("<br>");
	out.println("<br>");
	out.println("<input type='submit' value='search' name='search'>");
	out.println("</form>");
	out.println("</body>");
	out.println("</html>");
	}

}
