package org.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.domain.Actor;
import org.capgemini.domain.Film;
import org.capgemini.domain.Language;
import org.capgemini.service.IFilmService;
import org.capgemini.service.FilmServiceImpl;

/**
 * Servlet implementation class SearchServlet
 */
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		Film film=new Film();
		Set<Actor> selected_actors=new HashSet<>();
		IFilmService film_service=new FilmServiceImpl();
		List<Film> films=film_service.searchFilm(film);
		
		film.setFilm_Id(Integer.parseInt(request.getParameter("byId")));
		film.setTitle(request.getParameter("byTitle"));
		Language lang=new Language();
		Integer langId=Integer.parseInt(request.getParameter("ByLanguage"));
		lang.setLanguage_Id(langId);
		film.setOriginalLanguage(lang);
		String[] actors1=request.getParameterValues("actor");
		for(String act1:actors1)
		{
			Actor actor=new Actor();
			actor.setActor_Id(Integer.parseInt(act1));
			selected_actors.add(actor);
		}
		film.setActors(selected_actors);
		film_service.searchFilm(film);
		

		out.println("<html>");
		out.println("<head></head>"
				+ "<body>"
				+"<h1 align='center'>Film Details</h1>"
				+ "<div style='margin-left:500px;'><br>"
				+"</br> </div>"
				+ "<table border='1'>"
				+ "<tr>"
				+ "<th>Film Id</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "</tr>");
		
		for(Film f:films){
			out.println("<tr>");
			out.println("<td>"+f.getFilm_Id()+"</td>");
			out.println("<td>"+f.getTitle()+"</td>");
			out.println("<td>"+f.getDescription()+"</td>");
			out.println("</tr>");
		}
		out.println("</table></body>");
		
		out.println("</html>");
	}

}
