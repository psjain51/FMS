package org.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.domain.Actor;
import org.capgemini.domain.Category;
import org.capgemini.domain.Film;
import org.capgemini.domain.Language;
import org.capgemini.service.ActorServiceImpl;
import org.capgemini.service.FilmServiceImpl;
import org.capgemini.service.IActorService;
import org.capgemini.service.IFilmService;

/**
 * Servlet implementation class UpdateFormServlet
 */
public class UpdateFormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService film_service=new FilmServiceImpl();
		String filmid=request.getParameter("film_Id");
		DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
		Film film=new Film();
		
		film.setFilm_Id(Integer.parseInt(filmid));
		
		List<Film> films=film_service.searchFilm(film);
		
		
		IActorService actor_service=new ActorServiceImpl();
		List<Language> languages=film_service.getLanguages();
		Set<Actor> actors=actor_service.getActors();
		List<Category> category=film_service.getCategories();
		PrintWriter out=response.getWriter();
		
		for(Film f:films){
			System.out.println(f);
			out.println("<html>");
			out.println("<head><title>Update Film</title>"
					+"<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"
					+" <script src='http://code.jquery.com/jquery-1.10.2.js'></script>"
					+" <script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"
					);
			out.println("<script>"
	  				+"$(function() {"
	  				+"$( '#datepicker-13' ).datepicker({ maxDate: '0',dateFormat: 'dd-MM-yy' }).val();"
	  				+"$( '#datepicker-13' ).datepicker('show');"
	  				+"});"
	  				+"</script>"
	  				+"<script>"
	  				+"$(function() {"
	  				+" $('#datepicker-14').datepicker({dateFormat: 'dd-MM-yy'});"
	  				+"$( '#datepicker-14' ).datepicker('show');"
	  				+" });"
	  				+"</script>");
			out.println("</script>");
			out.println("<script type='text/javascript' src='Script/validate.js'></script>");
			out.println("</head>");
			out.println("<body>");
			out.println("<form id='updateForm' method='post' name='myForm' action='UpdateServlet'>");
			out.println("<table>"
					   +"<th>Update Film</th>"
					   +"<tr><td></td><td></td>"
					   +"</tr>"
					   +"<tr><td></td>"
					   +"</tr>"
					   +"<tr>"
					   +"<td>Film Title</td>"
					   +"<td><input type='text' name='title' value=" + f.getTitle() + " onmouseout='return  istitlevalidate()'/>"
					   +"<div id='titleErr' class='errMsg'></div>"
					   +"</td></tr>"
					   +"<tr>"
					   +"<td>Film Description</td>"
					   +"<td><textarea name='description' value="+ f.getDescription() +" onmouseout='return isdescriptionvalidate()'></textarea>"
					   +"<div id='descriptionErr' class='errMsg'></div>"
					   +"</td></tr>"
					   +"<tr>"
					   +"<td>Release Date</td>"
					   +"<td><input type='text' id='datepicker-13' name='release_date' value="+ df.format(f.getRealeaseYear()) +" placeholder='DD/MM/YYYY'></td>"
					   +"</tr>");
					   out.println("<tr>"
					   +"<td>Original Language</td>");
					   out.println("<td><select name='originallang' >");
					   for(Language lang:languages){
						   if((f.getOriginalLanguage().getLanguage_Name()).equals(lang.getLanguage_Name())){
							out.println("<option value='"+ lang.getLanguage_Id()+"' selected>"
									+lang.getLanguage_Name()+ "</option>");
						   }
						   else{
							   out.println("<option value='"+ lang.getLanguage_Id()+"'>"
										+lang.getLanguage_Name()+ "</option>");
						   }
							
					   }
					   
					 out.println("</select></td></tr>");
					   
					 out.println("<tr>"
							   +"<td>Languages</td>");
							   out.println("<td><select name='lang' multiple>");
							   for(Language lang1:f.getLanguages()){
							   for(Language lang:languages){
								  
								   if(lang1.getLanguage_Name().equals(lang.getLanguage_Name()))
								   {
									out.println("<option value='"+ lang.getLanguage_Id()+"' selected>"
											+lang.getLanguage_Name()+ "</option>");
								   }
									else{
										out.println("<option value='"+ lang.getLanguage_Id()+"'>"
												+lang.getLanguage_Name()+ "</option>");
									}
							      }	
							   }
							   
							 out.println("</select></td></tr>");
							   
			out.println("<tr>"
					   +"<td>Rental Duration</td>"
					   +"<td><input type='text' id='datepicker-14' name='rental_duration' value="+f.getRentalDuration()+">"
					   +"<div id='rentalErr' class='errMsg'></div></td>"
					   +"</tr><tr>"
					   +"<td>Length</td>"
					   +"<td><input type='text' name='length' value="+f.getLength()+" onmouseout='return isValidLength()'/>"
					   +"<div id='lengthErr' class='errMsg'></div>"
					   +"</td></tr>"
					   +"<tr>"
					   +"<td>Replacement Cost</td>"
					   +"<td><input type='text' name='replacement_cost' value="+f.getReplacementCost()+" onmouseout='return isreplacementvalidate()'/>"
					   +"<div id='replacement_costErr' class='errMsg'></div>"
					   +"</td></tr><tr>"
					   +"<td>Ratings</td>"
					   +"<td> <input type='radio' name='ratings' value='1' checked> 1"
					   +"<input type='radio' name='ratings' value='2' > 2"
					   	+"<input type='radio' name='ratings' value='3'> 3"
					   +"<input type='radio' name='ratings' value='4' > 4"
					   	+"<input type='radio' name='ratings' value='5'> 5"
					   +"<div id='ratingsErr' class='errMsg'></div>"
					   +"</td></tr><tr>"
					   +"<td>Special Feature</td>"
					   +"<td><textarea name='special_feature' value="+f.getSpecialFeatures()+" onmouseout='return isspecialvalidate()'></textarea>"
					   +"<div id='special_featureErr' class='errMsg'></div>"
					   +"</td></tr>"
					);
			
			 out.println("<tr>"
					   +"<td>Actors</td>");
					  out.println("<td><select name='actor' multiple>");
					  for(Actor act1:f.getActors()){
					   for(Actor act:actors){
						  
							if(act1.getFirstName().equals(act.getFirstName())){
							out.println("<option value='"+ act.getActor_Id()+"' selected>"
									+act.getFirstName()+" "+act.getLastName()+ "</option>");
							   }
						   else{
								   out.println("<option value='"+ act.getActor_Id()+"'>"
											+act.getFirstName()+" "+act.getLastName()+ "</option>");
							  }}
						  
						   	
					   }
					   
					 out.println("</select></td></tr>");
					 
					 out.println("<tr>"
							   +"<td>Category</td>");
							   out.println("<td><select name='category' >");
							   for(Category cat:category){
								   if((f.getCategory().getCategory_name()).equals(cat.getCategory_name())){
									out.println("<option value='"+ cat.getCategory_Id()+"' selected>"
											+cat.getCategory_name()+ "</option>");
								   }else{
									   out.println("<option value='"+ cat.getCategory_Id()+"'>"
												+cat.getCategory_name()+ "</option>"); 
								   }
							   }
							   
							 out.println("</select></td></tr>");
					 
			out.println("<tr>"
					+"<td></td>"
					+"<td><input type='submit' value='Update'>"
					+"<input type='reset' value='Clear'>"
					 +"</td>"
				+"</tr>");
	        out.println("</table>");
	        out.println("</form");
			out.println("</body>");
			out.println("</html>");
			
		
		}
			
		
		
		
		
	}

}