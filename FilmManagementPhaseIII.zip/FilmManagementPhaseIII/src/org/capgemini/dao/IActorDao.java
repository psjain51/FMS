package org.capgemini.dao;

import java.util.Set;

import org.capgemini.domain.Actor;

public interface IActorDao {

	public Set<Actor> getActors();
}
