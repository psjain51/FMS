package org.capgemini.service;



import java.util.Set;

import org.capgemini.dao.ActorDaoImplForList;
import org.capgemini.dao.IActorDao;
import org.capgemini.domain.Actor;



public class ActorServiceImpl implements IActorService{

	private IActorDao actorDao=new ActorDaoImplForList();
	
	@Override
	public Set<Actor> getActors() {
		// TODO Auto-generated method stub
		return actorDao.getActors();
	}

}

