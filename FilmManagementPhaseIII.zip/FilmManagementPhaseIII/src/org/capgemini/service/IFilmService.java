package org.capgemini.service;



import java.util.List;
import java.util.Map;

import org.capgemini.domain.Category;
import org.capgemini.domain.Film;
import org.capgemini.domain.Language;



public interface IFilmService {
	public List<Language> getLanguages();
	public List<Category> getCategories();
	public void addFilm(Film film);
	public List<Film> getAllFilms();
	public List<Film> searchFilm(Film film);
	public void removeFilm(Film film);
	public void updateFilm(Film film);
}