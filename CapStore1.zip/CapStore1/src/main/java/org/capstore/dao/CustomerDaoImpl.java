package org.capstore.dao;

import java.util.Date;


import org.capstore.domain.Customer;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import java.security.*;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;

import sun.misc.*;



@Repository
public class CustomerDaoImpl implements CustomerDao {

	//Password encryption decryption methods
	 private final static String ALGO = "AES";
	    private final static byte[] keyValue = 
	        new byte[] { 'T', 'h', 'e', 'B', 'e', 's', 't',
	'S', 'e', 'c', 'r','e', 't', 'K', 'e', 'y' };

	public static String encrypt(String Data) throws Exception {
	        Key key = generateKey();
	        Cipher c = Cipher.getInstance(ALGO);
	        c.init(Cipher.ENCRYPT_MODE, key);
	        byte[] encVal = c.doFinal(Data.getBytes());
	        String encryptedValue = new BASE64Encoder().encode(encVal);
	        return encryptedValue;
	    }

	    public static String decrypt(String encryptedData) throws Exception {
	        Key key = generateKey();
	        Cipher c = Cipher.getInstance(ALGO);
	        c.init(Cipher.DECRYPT_MODE, key);
	        byte[] decordedValue = new BASE64Decoder().decodeBuffer(encryptedData);
	        byte[] decValue = c.doFinal(decordedValue);
	        String decryptedValue = new String(decValue);
	        return decryptedValue;
	    }
	    private static Key generateKey() throws Exception {
	        Key key = new SecretKeySpec(keyValue, ALGO);
	        return key;
	}
	
	@Autowired
	private SessionFactory sessionFactory;

 @Transactional
public void saveCustomer(Customer customer) {
	String staticPart = "http://www.yoursite.com/foo/";

	//randomly generate the integer number and store in variable (e.g. ranNum)

	int ranNum = (int) (Math.random()*1000);
	String finalURL = staticPart + Integer.toString(ranNum);

Session session = this.sessionFactory.getCurrentSession();
session.beginTransaction();
customer.setRegdate(new Date());
customer.setVerification_code(finalURL);
customer.setEmail_verified(0);

//Using encrypt password method
String passwordEnc=null;
try {
	 passwordEnc = encrypt(customer.getPassword());
} catch (Exception e1) {
	e1.printStackTrace();
}
customer.setPassword(passwordEnc);


int car=(int) (Math.random()*5000);
System.out.println(car);
customer.setCart_id(car);


sessionFactory.getCurrentSession().save(customer);
session.getTransaction().commit();
	
}

	


}
