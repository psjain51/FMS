function sayHello(){
	alert('hai');
}