package com.flp.fms.view;

import java.util.Collection;
import java.util.Map;
import java.util.Scanner;

import com.flp.fms.domain.Film;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

public class BootClass {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int option;
		UserInteraction userInteraction=new UserInteraction();
		IFilmService filmService=new FilmServiceImpl();
		IActorService actorService=new ActorServiceImpl();
		String choice=null;
		
		do{
		
			menuSelection();
			System.out.println("Enter your option:[1-6]");
			option=sc.nextInt();
			switch(option){
				case 1:
					Film film=userInteraction.addFilm(filmService.getLanguages(), filmService.getCategories(), actorService.getActors());
					filmService.addFilm(film);
					break;
				case 2://Modify Film
					break;
				case 3://Remove Film
					Map<Integer, Film>  film_lst= filmService.getAllFilms();
					Collection<Film> lst=film_lst.values();
					userInteraction.removeFilm(lst);
					break;
				case 4://Search film
					Map<Integer, Film>  film_lst2= filmService.getAllFilms();
					Collection<Film> lst2=film_lst2.values();
					userInteraction.searchFilm(lst2);
					break;
				case 5://Print film Repository
					Map<Integer, Film>  film_lst1= filmService.getAllFilms();
					Collection<Film> lst1=film_lst1.values();
					userInteraction.getAllFilm(lst1);
					break;
				case 6://Exit
					System.exit(0);
			}
		System.out.println("Wish to do more Operation?[y|n]");
		choice=sc.next();
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
	}

	public static void menuSelection(){
		System.out.println("1.Add Film");
		System.out.println("2.Modify Film");
		System.out.println("3.Remove Film");
		System.out.println("4.Search Film");
		System.out.println("5.GetAll Film");
		System.out.println("6.Exit");
		
	}
	
	
}
