package com.flp.fms.view;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.util.Validate;

public class UserInteraction {
	
	Scanner sc=new Scanner(System.in);
	
	//Return fully qualified film object
	public Film addFilm(List<Language> languages, List<Category> categories, Set<Actor> actors){
		
		//Create Film Object
		Film film=new Film();
		boolean flag=true;
		
		//Get Title and validate it
		String title=null;
		do{
		System.out.println("Enter Film Title");
		title=sc.nextLine();
		flag=Validate.isValidTitle(title);
			if(!flag)
				System.out.println("Invalid Title. Please Enter Valid Title!");
		}while(!flag);
		film.setTitle(title);
		
		
		
		//Release Date Validation
		String releaseDate;
		boolean date_flag=false;
		Date release_Date=null;
		do{
			
			//Verify Date Format
			do{
				System.out.println("Enter Release Date:");
				releaseDate=sc.next();
				flag=Validate.isValidDate(releaseDate);
				if(!flag)
					System.out.println("Please enter date in this Format(dd-MMM-yyyy)!");
			}while(!flag);
			
			//Verifies Release Date  
			Date today=new Date();
			release_Date=new Date(releaseDate);
			if(release_Date.before(today)|| release_Date.equals(today))
				date_flag=true;
		
			if(!date_flag)
				System.out.println("Invalid Date! Date should be current date or Past Date!");
		}while(!date_flag);
		film.setRealeaseYear(release_Date);
		
		//Verify film length
		int length;
		do{
			System.out.println("Enter film length:");
			length=sc.nextInt();
			flag=Validate.isValidLength(length);
			if(!flag){
				System.out.println("Invalid entry. Please Try again");
			}
			}while(!flag);
			film.setLength(length);
		
		//Verify film ratings
		int ratings;
		do{
			System.out.println("Enter film ratings:");
			ratings=sc.nextInt();
			flag=Validate.isValidRatings(ratings);
			if(!flag){
				System.out.println("Invalid entry. Please Try again");
			}
			}while(!flag);
			film.setRatings(ratings);	
		
		//Verify rental date
		String rental;
		date_flag=false;
		Date rentalDuration=null;
		do{
			
			//Verify Date Format
			do{
				System.out.println("Enter Rental Date:");
				rental=sc.next();
				flag=Validate.isValidDate(rental);
				if(!flag)
					System.out.println("Please enter date in this Format(dd-MMM-yyyy)!");
			}while(!flag);
			
			//Verifies Rental Date  
			Date today=new Date();
			rentalDuration=new Date(rental);
			if(rentalDuration.after(release_Date))
				date_flag=true;
		
			if(!date_flag)
				System.out.println("Invalid Date! Date should be Future Date!");
		}while(!date_flag);
		film.setRentalDuration(rentalDuration);
		
		//Verify Replacement Cost
		double replacementCost;
		do{
			System.out.println("Enter replacement cost:");
			replacementCost=sc.nextDouble();
			flag=Validate.isValidReplacementCost(replacementCost);
			if(!flag){
				System.out.println("Invalid entry. Please Try again");
			}
			
		}while(!flag);
		film.setReplacementCost(replacementCost);
		
		
		//Choose Language
		System.out.println("Choose Original Language");
		Language language= addLanguage(languages);
		film.setOriginalLanguage(language);
		
		
		//Add all languages
		List<Language> languages2=new ArrayList<>();
		String choice;
		boolean flag_langs;
		do{
			System.out.println("Choose All Languages for the Film:");
			Language language1= addLanguage(languages);
			
			
			flag_langs=Validate.checkDuplicateLanguage(languages2, language1);
			if(!flag_langs)
				languages2.add(language1);
			else
				System.out.println("Language already Exists. Please try other languages!");
			
			
			System.out.println("Wish to add More Languages?[y|n]");
			choice=sc.next();
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		film.setLanguages(languages2);
		
		//Choose Category
				System.out.println("Choose Category");
				Category category= selectCategory(categories);
				film.setCategory(category);
		
		
		
		//Add all Actors
		
		Set<Actor> actors2=new HashSet<>();
		do{
			System.out.println("Choose All Actors for the Film:");
			Actor actor=addActor(actors);
			actors2.add(actor);
			
			System.out.println("Wish to add More Actors?[y|n]");
			choice=sc.next();
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		film.setActors(actors2);
		
		
		
		
		return film;
	}
	
	
	
	
	
	//Choose Valid Language Object from the list of Languages
	public Language addLanguage(List<Language>  languages){
		
		Language sel_language=null;
		boolean flag;
		do{	
			//Print Langauge Details
			for(Language language:languages)
				System.out.println(language.getLanguage_Id() + "\t" + language.getLanguage_Name());
			
			System.out.println("Choose the Language:");
			int option=sc.nextInt();
			
			flag=false;
			
			//Check the Language Object
			for(Language language: languages)
			{
				if(option==language.getLanguage_Id())
				{
					sel_language=language;
					flag=true;
					break;
				}
			}
			
			//Print Error Message
			if(!flag)
				System.out.println("Please select valid Language Id");
		}while(!flag);	
		
		return sel_language;
	}
	
public Category selectCategory(List<Category>  categories){
		
		Category sel_category=null;
		boolean flag;
		do{	
			//Print Category Details
			for(Category category:categories)
				System.out.println(category.getCategory_Id() + "\t" + category.getCategory_name());
			
			System.out.println("Choose the Category:");
			int option=sc.nextInt();
			
			flag=false;
			
			//Check the Category Object
			for(Category category:categories)
			{
				if(option==category.getCategory_Id())
				{
					sel_category=category;
					flag=true;
					break;
				}
			}
			
			//Print Error Message
			if(!flag)
				System.out.println("Please select valid category!");
		}while(!flag);	
		
		return sel_category;
	}
	
	//Choose Valid Actor Object from the list of Actors
	public Actor addActor(Set<Actor> actors){
		
		Actor sel_actor=null;
		boolean flag=false;
		
		do{	
		for(Actor actor:actors)
			System.out.println(actor.getActor_Id() + "\t" + actor.getFirstName() + "\t" + actor.getLastName());
		
		System.out.println("Choose the Actor:");
		int option=sc.nextInt();
		
		flag=false;
		
		//Check the Actor Object
		for(Actor actor: actors)
		{
			if(option==actor.getActor_Id())
			{
				sel_actor=actor;
				flag=true;
				break;
			}
		}
			
		
		//Print Error Message
		if(!flag)
			System.out.println("Please select valid Actor Id");
		}while(!flag);	
		
		return sel_actor;
	}





	public void getAllFilm(Collection<Film> lst) {
		
		
		
		for(Film film:lst){
			String languages="";
			for(Language language:film.getLanguages())
				languages=languages+language.getLanguage_Name()+",";
			
			
			
			System.out.println(film.getFilm_Id() + "\t" +
					film.getTitle() + "\t"+
					film.getRealeaseYear() + "\t"+
					film.getRentalDuration()+"\t"+
					film.getReplacementCost()+"\t"+
					film.getRatings()+"\t"+ film.getOriginalLanguage()+
					"\t"+languages+"\t"+film.getCategory()+
					"\t"+film.getActors());
			}
		
	}
	
	
	public void searchFilm(Collection<Film> lst){
		System.out.println("1. Search by Film ID \n 2. Search by Title \n 3. Search by Rating");
		System.out.println("Enter option to be searched:");
		int option=sc.nextInt();
		
		switch(option){
		case 1: System.out.println("Enter film ID to be searched:");
				int fids=sc.nextInt();
				for(Film film:lst){
				if(fids==film.getFilm_Id()){
					System.out.println(film);
					break;
				}else{
					System.out.println("Film not found!");
				}
				}break;
		case 2: System.out.println("Enter film title to be searched:");
				String str=sc.nextLine();
				for(Film film:lst){
				if(str==film.getTitle()){
					System.out.println(film);
					break;
				}else{
					System.out.println("Film not found!");
				}
				}break;
		case 3: List<Film> ratlst=new ArrayList<Film>();
				System.out.println("Enter film ratings to be searched:");
				int rat=sc.nextInt();
				for(Film film:lst){
					if(rat==film.getRatings()){
						ratlst.add(film);
					}
				}
				System.out.println(ratlst);
				break;
		}
		
		
	}
	
	public Film removeFilm(Collection<Film> lst){
		System.out.println("1. Remove by Film ID \n 2. Remove by Title");
		System.out.println("Enter option:");
		int option=sc.nextInt();
		
		switch(option){
		case 1: System.out.println("Enter film ID to be Removed:");
				int fids=sc.nextInt();
				for(Film film:lst){
				if(fids==film.getFilm_Id()){
					lst.remove(film);
					return film;
					
				}else{
					System.out.println("Film not found!");
				}
				}break;
		case 2: System.out.println("Enter film title to be Removed:");
				String str=sc.nextLine();
				for(Film film:lst){
				if(str==film.getTitle()){
					lst.remove(film);
					return film;
					
				}else{
					System.out.println("Film not found!");
				}
				}break;
//		case 3: List<Film> ratlst=new ArrayList<Film>();
//				System.out.println("Enter film ratings to be Removed:");
//				int rat=sc.nextInt();
//				for(Film film:lst){
//					if(rat==film.getRatings()){
//						ratlst.remove(film);
//					}
//				}
//				System.out.println(ratlst);
//				break;
				
		}
		return null;
	}
	
	
	public Film modifyFilm(Collection<Film> lst) {
		
		System.out.println("1. Modify by Film ID \n 2. Modify by Title");
		System.out.println("Enter option:");
		int option=sc.nextInt();
		
		switch(option){
		case 1: System.out.println("Enter film ID to be modified:");
				int fids=sc.nextInt();
				for( Film film:lst){
				if(fids==film.getFilm_Id()){
					System.out.println(film);
					break;
				}else{
					System.out.println("Film not found!");
				}
				}break;
		case 2: System.out.println("Enter film title to be modified:");
				String str=sc.nextLine();
				for(Film film:lst){
				if(str==film.getTitle()){
					System.out.println(film);
					break;
				}else{
					System.out.println("Film not found!");
				}
				}break;
		
		}
		return null;
	}
	

}
