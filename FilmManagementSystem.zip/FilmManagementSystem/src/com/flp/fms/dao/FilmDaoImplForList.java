package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmDaoImplForList implements IFilmDao{

	
	private Map<Integer, Film> film_Repository=new HashMap<>();
	
public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila","root","Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return connection;
	}
	
	
	@Override
	public List<Language> getLanguages() {
		List<Language> languages=new ArrayList<>();
		/*languages.add(new Language(1, "English"));
		languages.add(new Language(2, "Hindi"));
		languages.add(new Language(3, "Telugu"));
		languages.add(new Language(4, "Marathi"));
		languages.add(new Language(5, "Kannada"));
		languages.add(new Language(6, "Tamil"));
		languages.add(new Language(7, "Malayalam"));
		*/
        Connection con=getConnection();
		
		String sql="select language_id,name from language";
		
		try {
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery(sql);
			
			while(rs.next()){
				
				languages.add(new Language(rs.getInt(1), rs.getString(2)));
				
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	
		return languages;
	}
	
	@Override
	public List<Category> getCategories() {
		List<Category> categories=new ArrayList<>();
		/*categories.add(new Category(1, "Horror"));
		categories.add(new Category(2, "Drama"));
		categories.add(new Category(3, "Romance"));
		categories.add(new Category(4, "Action"));
		categories.add(new Category(5, "Adventure"));
		categories.add(new Category(6, "Documentary"));
		categories.add(new Category(7, "Comedy"));*/
		   Connection con=getConnection();
			
			String sql="select category_id,name from category";
			
			try {
				Statement stmt=con.createStatement();
				
				ResultSet rs=stmt.executeQuery(sql);
				
				while(rs.next()){
					
					categories.add(new Category(rs.getInt(1), rs.getString(2)));
					
				}
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
		
		return categories;
	}
	
	//CURD Operation
	@Override
	public void addFilm(Film film) {
		film_Repository.put(film.getFilm_Id(), film);
		
	}


	@Override
	public Map<Integer, Film> getAllFilms() {
		
		return film_Repository;
	}

	@Override
	public void removeFilm(Film film) {
		film_Repository.remove(film.getFilm_Id(), film);
		
	}

}
